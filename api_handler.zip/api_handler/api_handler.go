package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"time"

	"./memory"
	"./storage"
)

var duration = "30m"
var storage cache.Storage

func key(w http.ResponseWriter, r *http.Request) {
	//set in mem storage
	storage = memory.NewStorage()
	//set all things to UTF8
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	//Set up cache cleaning

	//Methods for get/post
	switch r.Method {

	case "POST":
		defer r.Body.Close()
		res, err := ioutil.ReadAll(r.Body)
		if err != nil {
			log.Fatal(err)
			http.Error(w, "Error reading request body", http.StatusInternalServerError)
			return
		}
		key := (string(res))
		if d, err := time.ParseDuration(duration); err == nil {
			storage.Set(key, res, d)
		} else {
			log.Fatal(err)
			http.Error(w, "Error reading request body", http.StatusInternalServerError)
		}
	case "GET":
		///get request
		defer r.Body.Close()
		res, err := ioutil.ReadAll(r.Body)
		if err != nil {
			log.Fatal(err)
		}

		oldkey := (string(res))
		log.Println(oldkey)
		//Does this exist in the cache if not 404
		if keys, err := time.ParseDuration(duration); err == nil {
			storage.Get(oldkey)
			log.Println(keys)
			w.Write([]byte(oldkey))
			return
		} else {
			log.Fatal(err)
			http.Error(w, "404 not found.", http.StatusNotFound)
		}
		return
	default:
		fmt.Fprintf(w, "Sorry, only GET and POST methods are supported.")
	}

}

//Http Server
func main() {
	http.HandleFunc("/", key)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
